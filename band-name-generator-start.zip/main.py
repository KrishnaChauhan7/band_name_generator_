print("Welcome to the Band Nmae Generator")
city_name = input("What's name of the city you grew up in?\n")
pet_name = input("What's your pet's name?\n")

print("Your band name could be"+" "+city_name+" "+ pet_name)